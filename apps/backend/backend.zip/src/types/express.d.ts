declare global {
  namespace Express {
    interface Request {
      user?: {
        id: string;
        email: string;
        firstName?: string;
        lastName?: string;
        role: 'USER' | 'ADMIN';
      };
    }
  }
}

export {};